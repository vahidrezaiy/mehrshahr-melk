MehrshahrMelk — وب فارسی (مشکی/طلایی) + AI proxy (Node.js)

این بسته شامل یک اپ وب RTL فارسی و یک سرور ساده برای فراخوانی Vertex AI است.

مراحل سریع:
1. Extract این ZIP
2. در پوشه frontend: npm install && npm start
3. در پوشه functions: npm install && node index.js (یا deploy to Cloud Run)

برای فعال کردن AI، باید Service Account GCP را تنظیم کنید و env vars را پیاده کنید (راهنما در functions/README.md).
