const express = require('express');
const cors = require('cors');
const {GoogleAuth} = require('google-auth-library');
const axios = require('axios');
const app = express();
app.use(cors()); app.use(express.json());

async function getAccessToken(){
  const auth = new GoogleAuth({scopes:['https://www.googleapis.com/auth/cloud-platform']});
  const client = await auth.getClient();
  const token = await client.getAccessToken();
  return token.token;
}

app.post('/api/ai', async (req,res)=>{
  try{
    const { prompt } = req.body;
    if(!prompt) return res.status(400).json({error:'missing prompt'});
    const project = process.env.VERTEX_PROJECT_ID;
    const location = process.env.VERTEX_LOCATION || 'us-central1';
    const model = process.env.VERTEX_MODEL || 'models/text-bison@001';
    const url = `https://${location}-aiplatform.googleapis.com/v1/projects/${project}/locations/${location}/${model}:predict`;
    const accessToken = await getAccessToken();
    const body = {instances:[{content: prompt}], parameters:{maxOutputTokens:512}};
    const r = await axios.post(url, body, {headers:{'Authorization':`Bearer ${accessToken}`,'Content-Type':'application/json'}});
    res.json(r.data);
  }catch(err){
    console.error(err?.response?.data || err.message || err);
    res.status(500).json({error: err?.response?.data || err.message});
  }
});

const PORT = process.env.PORT || 5000;app.listen(PORT, ()=>console.log('AI proxy listening on', PORT));
module.exports = app;
