# AI Proxy

This simple proxy forwards requests to Vertex AI. Set env vars:
- VERTEX_PROJECT_ID
- VERTEX_LOCATION
- VERTEX_MODEL
and ensure GOOGLE_APPLICATION_CREDENTIALS is set to a service-account.json for google-auth-library.

Run locally:
cd functions
npm install
node index.js

Deploy to Cloud Run or Cloud Functions for production.
