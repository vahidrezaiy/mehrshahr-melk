import React from 'react';
import Home from './pages/Home';
import Ads from './pages/Ads';
import AiChat from './pages/AiChat';
import About from './pages/About';
import Header from './components/Header';
export default function App(){
  return (
    <div className='app'>
      <Header />
      <main>
        <Home />
        <Ads />
        <AiChat />
        <About />
      </main>
      <footer className='footer'>© مهرشهرملک — کرج، مهرشهر</footer>
    </div>
  );
}
