import React from 'react';
import logo from '../logo.svg';
export default function Header(){
  return (
    <header className='header'>
      <div className='logo'>
        <div dangerouslySetInnerHTML={{__html: logo}} />
        <div className='title'>مهرشهرملک</div>
      </div>
      <nav className='nav'>
        <a href='#ads'>آگهی‌ها</a>
        <a href='#ai'>هوش مصنوعی</a>
        <a href='#about'>درباره ما</a>
      </nav>
    </header>
  );
}
