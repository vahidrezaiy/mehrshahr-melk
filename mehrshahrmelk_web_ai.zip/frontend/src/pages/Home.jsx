import React from 'react';
export default function Home(){
  return (
    <section className='section' id='home'>
      <h2 style={{color:'var(--gold)'}}>خوش آمدید به مهرشهرملک</h2>
      <p>سامانهٔ جامع املاک مهرشهر — جستجو، ثبت و تبلیغ املاک با تولید متن تبلیغاتی هوش‌مصنوعی.</p>
    </section>
  );
}
