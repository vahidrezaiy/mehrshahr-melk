import React, {useState} from 'react';
const sample = [
  {id:1,title:'آپارتمان 3 خوابه',price:'4,500,000,000',area:'مهرشهر',type:'مسکونی'},
  {id:2,title:'مغازه در مرکز تجاری',price:'2,200,000,000',area:'مهرشهر',type:'تجاری'},
  {id:3,title:'ویلای لوکس',price:'12,000,000,000',area:'مهرشهر',type:'ویلایی'}
];
export default function Ads(){
  const [q,setQ] = useState('');
  const filtered = sample.filter(a=> a.title.includes(q) || a.type.includes(q) || a.area.includes(q));
  return (
    <section className='section' id='ads'>
      <h3 style={{color:'var(--gold)'}}>آگهی‌ها</h3>
      <input placeholder='جستجو' value={q} onChange={e=>setQ(e.target.value)} />
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:12,marginTop:12}}>
        {filtered.map(a=> (
          <div key={a.id} className='card'>
            <h4>{a.title}</h4>
            <p style={{color:'var(--gold)'}}>{a.price} تومان</p>
            <p style={{color:'#aaa'}}>{a.area} — {a.type}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
