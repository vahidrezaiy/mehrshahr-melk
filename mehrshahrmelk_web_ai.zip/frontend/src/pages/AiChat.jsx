import React, {useState} from 'react';
import axios from 'axios';
export default function AiChat(){
  const [prompt,setPrompt] = useState('');
  const [resp,setResp] = useState('');
  const [loading,setLoading] = useState(false);
  const callAi = async ()=>{
    if(!prompt) return; setLoading(true); setResp('');
    try{
      const r = await axios.post('/api/ai', {prompt});
      setResp(JSON.stringify(r.data).slice(0,2000));
    }catch(e){ setResp('خطا در ارتباط با سرویس هوش مصنوعی'); }
    setLoading(false);
  }
  return (
    <section className='section' id='ai'>
      <h3 style={{color:'var(--gold)'}}>هوش مصنوعی مهرشهرملک</h3>
      <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder='توصیف ملک یا درخواست متن تبلیغاتی...' style={{width:'100%',minHeight:120,padding:8}} />
      <div style={{marginTop:8}}>
        <button className='btn' onClick={callAi} disabled={loading}>{loading? 'در حال ارسال...':'ارسال به AI'}</button>
      </div>
      <div style={{marginTop:12,whiteSpace:'pre-wrap'}} className='card'>{resp}</div>
    </section>
  );
}
