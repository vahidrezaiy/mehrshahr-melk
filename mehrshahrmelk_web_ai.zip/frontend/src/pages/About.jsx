import React from 'react';
export default function About(){
  return (
    <section className='section' id='about'>
      <h3 style={{color:'var(--gold)'}}>درباره ما</h3>
      <p>دفتر مهرشهرملک</p>
      <p>شماره‌ها:</p>
      <ul>
        <li>09920665564</li>
        <li>09309771230</li>
        <li>09108831988</li>
      </ul>
      <p>آدرس: کرج، مهرشهر، فاز ۲، نبش خیابان ۲۰۳</p>
    </section>
  );
}
