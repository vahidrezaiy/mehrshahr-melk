MehrshahrMelk Web + AI Proxy

Contents:
- frontend/ (React app)
- functions/ (Node.js AI proxy)

Quick start:
1. frontend:
   cd frontend
   npm install
   npm start
2. backend:
   cd functions
   npm install
   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
   export VERTEX_PROJECT_ID=your-project-id
   export VERTEX_LOCATION=us-central1
   export VERTEX_MODEL=models/text-bison@001
   node index.js

For production, deploy frontend to Firebase Hosting/Netlify/Vercel and backend to Cloud Run or Cloud Functions.
